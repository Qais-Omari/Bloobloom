require "test_helper"

class FrameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
