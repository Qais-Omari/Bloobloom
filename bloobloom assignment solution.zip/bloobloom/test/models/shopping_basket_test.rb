require "test_helper"

class ShoppingBasketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
