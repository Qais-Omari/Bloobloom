require "test_helper"

class ShoppingBasketsControllerTest < ActionDispatch::IntegrationTest
  test "should get create" do
    get shopping_baskets_create_url
    assert_response :success
  end
end
