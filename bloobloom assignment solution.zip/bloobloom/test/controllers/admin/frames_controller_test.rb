require "test_helper"

class Admin::FramesControllerTest < ActionDispatch::IntegrationTest
  test "should get create" do
    get admin_frames_create_url
    assert_response :success
  end
end
