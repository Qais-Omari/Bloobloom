require "test_helper"

class Admin::PricesControllerTest < ActionDispatch::IntegrationTest
  test "should get create" do
    get admin_prices_create_url
    assert_response :success
  end
end
