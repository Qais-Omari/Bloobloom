require "test_helper"

class Admin::LensesControllerTest < ActionDispatch::IntegrationTest
  test "should get create" do
    get admin_lenses_create_url
    assert_response :success
  end
end
