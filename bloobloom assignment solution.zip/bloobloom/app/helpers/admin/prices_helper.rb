module Admin::PricesHelper
end
