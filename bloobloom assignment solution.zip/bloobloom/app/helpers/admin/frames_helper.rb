module Admin::FramesHelper
end
