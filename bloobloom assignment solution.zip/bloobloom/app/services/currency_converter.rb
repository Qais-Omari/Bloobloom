require 'json'
require 'net/http'

class CurrencyConverter
  def self.convert(amount, from_currency, to_currency)
    response = Net::HTTP.get(URI("https://api.exchangerate-api.com/v4/latest/#{from_currency}"))
    exchange_rates = JSON.parse(response)['rates']
    converted_amount = amount * exchange_rates[to_currency]
    converted_amount.round(2)
  end
end
