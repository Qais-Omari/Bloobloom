class Frame < ApplicationRecord
  enum currency: { USD: 'USD', GBP: 'GBP', EUR: 'EUR', JOD: 'JOD', JPY: 'JPY' }

  validates :name, presence: true
  validates :description, presence: true
  validates :status, presence: true
  validates :stock, presence: true
  validates :price, presence: true
  validates :currency, presence: true, inclusion: { in: currencies.keys }
end
