class ShoppingBasket < ApplicationRecord
  belongs_to :frame
  belongs_to :len
end
