class Len < ApplicationRecord
  enum currency: { USD: 'USD', GBP: 'GBP', EUR: 'EUR', JOD: 'JOD', JPY: 'JPY' }

  validates :colour, presence: true
  validates :description, presence: true
  validates :prescription_type, presence: true
  validates :lens_type, presence: true
  validates :stock, presence: true
  validates :price, presence: true
  validates :currency, presence: true, inclusion: { in: currencies.keys }
end
