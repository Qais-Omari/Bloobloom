class Admin::LensesController < ApplicationController
  before_action
  def create
    @lens = Len.new(lens_params)

    if @lens.save
      render json: @lens, status: :created
    else
      render json: @lens.errors, status: :unprocessable_entity
    end
  end

  private

  # Only allow a trusted parameter "white list" through.
  def lens_params
    params.require(:lens).permit(:colour, :description, :prescription_type, :lens_type, :stock, :price, :currency)
  end
end
