class Admin::FramesController < ApplicationController
  def create
    @frame = Frame.new(frame_params)

    if @frame.save
      render json: @frame, status: :created
    else
      render json: @frame.errors, status: :unprocessable_entity
    end
  end

  private
  def frame_params
    params.require(:frame).permit(:name, :description, :status, :stock, :price, :currency)
  end
end
