class ShoppingBasketsController < ApplicationController
  def create
    frame = Frame.find(params[:frame_id])
    lens = Len.find(params[:lens_id])

    # Check if both frame and lens are in stock
    if frame.stock > 0 && lens.stock > 0
      # Perform the database transaction
      ActiveRecord::Base.transaction do
        # Create the shopping basket
        @shopping_basket = ShoppingBasket.new(
          frame: frame,
          len: lens,
          price: calculate_price(frame, lens, params[:currency]),
          currency: params[:currency]
        )

        # Decrement the stock for both frame and lens
        frame.decrement!(:stock)
        lens.decrement!(:stock)

        # Save the shopping basket
        @shopping_basket.save!

        render json: { price: @shopping_basket.price }
      end
    else
      render json: { error: 'Frame or lens is out of stock' }, status: :unprocessable_entity
    end
  rescue ActiveRecord::RecordNotFound
    render json: { error: 'Frame or lens not found' }, status: :not_found
  end

  def calculate_price(frame, lens, currency)
    convert(frame.price, frame.currency, currency) + convert(lens.price, lens.currency, currency)
  end

  private
  def convert(amount, price, currency)
    CurrencyConverter.convert amount, price, currency
  end
end
