class LensesController < ApplicationController
  def index
    @lenses = Len.all
    render json: @lenses
  end
end
