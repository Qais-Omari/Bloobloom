class CreateLens < ActiveRecord::Migration[7.1]
  def change
    create_table :lens do |t|
      t.string :colour
      t.text :description
      t.integer :prescription_type
      t.integer :lens_type
      t.integer :stock
      t.float :price

      t.timestamps
    end
  end
end
