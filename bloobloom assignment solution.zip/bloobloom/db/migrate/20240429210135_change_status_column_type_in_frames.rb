class ChangeStatusColumnTypeInFrames < ActiveRecord::Migration[7.1]
  def change
    # Alter the status column to an enum
    reversible do |dir|
      dir.up do
        execute <<-SQL
          CREATE TYPE frame_status AS ENUM ('active', 'inactive');
          ALTER TABLE frames ADD COLUMN status_new frame_status;
          UPDATE frames SET status_new = CASE status WHEN 0 THEN 'active' ELSE 'inactive' END::frame_status;
          ALTER TABLE frames DROP COLUMN status;
          ALTER TABLE frames RENAME COLUMN status_new TO status;
        SQL
      end

      dir.down do
        execute <<-SQL
          ALTER TABLE frames RENAME COLUMN status TO status_new;
          CREATE TYPE frame_status AS ENUM ('active', 'inactive');
          ALTER TABLE frames ADD COLUMN status integer;
          UPDATE frames SET status = CASE status_new WHEN 'active' THEN 0 ELSE 1 END;
          ALTER TABLE frames DROP COLUMN status_new;
        SQL
      end
    end
  end
end
