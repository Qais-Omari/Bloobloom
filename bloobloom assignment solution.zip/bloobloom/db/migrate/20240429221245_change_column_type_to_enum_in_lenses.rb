class ChangeColumnTypeToEnumInLenses < ActiveRecord::Migration[7.1]
  def up
    # Create enum types
    execute <<-SQL
      CREATE TYPE lens_prescription_type AS ENUM ('fashion', 'single_vision', 'varifocal');
      CREATE TYPE lens_lens_type AS ENUM ('classic', 'blue_light', 'transition');
    SQL

    # Add new columns with enum types
    add_column :lens, :prescription_type_new, :lens_prescription_type
    add_column :lens, :lens_type_new, :lens_lens_type

    # Update new columns with enum values based on existing integer values
    execute <<-SQL
      UPDATE lens SET prescription_type_new = CASE prescription_type
                                                  WHEN 0 THEN 'fashion'::lens_prescription_type
                                                  WHEN 1 THEN 'single_vision'::lens_prescription_type
                                                  WHEN 2 THEN 'varifocal'::lens_prescription_type
                                                END,
                          lens_type_new = CASE lens_type
                                           WHEN 0 THEN 'classic'::lens_lens_type
                                           WHEN 1 THEN 'blue_light'::lens_lens_type
                                           WHEN 2 THEN 'transition'::lens_lens_type
                                         END;
    SQL

    # Remove old integer columns
    remove_column :lens, :prescription_type
    remove_column :lens, :lens_type

    # Rename new columns to original column names
    rename_column :lens, :prescription_type_new, :prescription_type
    rename_column :lens, :lens_type_new, :lens_type
  end

  def down
    # Revert the changes by dropping the enum types and adding back the old integer columns
    execute <<-SQL
      ALTER TABLE lens DROP COLUMN prescription_type;
      ALTER TABLE lens DROP COLUMN lens_type;
      DROP TYPE lens_prescription_type;
      DROP TYPE lens_lens_type;
    SQL

    add_column :lens, :prescription_type, :integer
    add_column :lens, :lens_type, :integer
  end
end
