class AddCurrencyToShoppingBasket < ActiveRecord::Migration[7.1]
  def change
    add_column :shopping_baskets, :currency, :enum, limit: [:USD, :GBP, :EUR, :JOD, :JPY], default: :USD, null: false, enum_type: 'currency_enum'
  end
end
