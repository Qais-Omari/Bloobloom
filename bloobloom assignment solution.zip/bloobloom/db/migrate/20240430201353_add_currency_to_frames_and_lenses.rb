class AddCurrencyToFramesAndLenses < ActiveRecord::Migration[7.1]
  def change
    execute <<-SQL
      CREATE TYPE currency_enum AS ENUM ('USD', 'GBP', 'EUR', 'JOD', 'JPY');
    SQL
    add_column :frames, :currency, :enum, limit: [:USD, :GBP, :EUR, :JOD, :JPY], default: :USD, null: false, enum_type: 'currency_enum'
    add_column :lens, :currency, :enum, limit: [:USD, :GBP, :EUR, :JOD, :JPY], default: :USD, null: false, enum_type: 'currency_enum'
  end
end
